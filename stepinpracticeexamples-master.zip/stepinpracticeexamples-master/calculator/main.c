#include "test_calculator.h"

int main(void)
{
	test_main();
	return 0;
}
