@mainpage Calculator Application by NIRANJAN KUMAR M
@subpage calculator.h
