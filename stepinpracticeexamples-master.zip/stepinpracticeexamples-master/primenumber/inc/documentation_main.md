@mainpage Primenumber Application by NIRANJAN KUMAR M
@subpage primenumber.h
