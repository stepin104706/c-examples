#ifndef __TEST_PRIMENUMBER_H__
#define __TEST_PRIMENUMBER_H__

int test_main(void);

#endif 
